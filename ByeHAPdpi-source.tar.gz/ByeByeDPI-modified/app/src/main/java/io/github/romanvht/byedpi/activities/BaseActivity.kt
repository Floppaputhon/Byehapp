package io.github.romanvht.byedpi.activities

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.DynamicColors
import io.github.romanvht.byedpi.utility.HuaweiUtils
import io.github.romanvht.byedpi.utility.SettingsUtils
import io.github.romanvht.byedpi.utility.getPreferences
import io.github.romanvht.byedpi.utility.getStringNotNull

abstract class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getPreferences()

        val lang = prefs.getStringNotNull("language", "system")
        SettingsUtils.setLang(lang)

        val theme = prefs.getStringNotNull("app_theme", "system")
        SettingsUtils.setTheme(theme)

        // Huawei EMUI 15 / HarmonyOS NEXT не поддерживает Material You DynamicColors
        // без установленных HMS Core. Безопасно пропускаем на Huawei-устройствах.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && HuaweiUtils.supportsDynamicColors) {
            try {
                DynamicColors.applyToActivityIfAvailable(this)
            } catch (_: Exception) {
                // Игнорируем — EMUI может не поддерживать Monet
            }
        }

        super.onCreate(savedInstanceState)
    }
}
