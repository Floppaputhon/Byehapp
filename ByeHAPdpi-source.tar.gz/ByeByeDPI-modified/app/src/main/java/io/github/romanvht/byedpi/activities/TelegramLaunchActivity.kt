package io.github.romanvht.byedpi.activities

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.data.AppStatus
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.databinding.ActivityTelegramLaunchBinding
import io.github.romanvht.byedpi.services.ServiceManager
import io.github.romanvht.byedpi.services.appStatus
import io.github.romanvht.byedpi.utility.*
import kotlinx.coroutines.*

class TelegramLaunchActivity : BaseActivity() {

    private lateinit var binding: ActivityTelegramLaunchBinding
    private var searchJob: Job? = null

    // Telegram package names (официальный + FOSS форки)
    private val TG_PACKAGES = listOf(
        "org.telegram.messenger",          // Official
        "org.telegram.messenger.web",      // Official Web
        "org.thunderdog.challegram",       // Telegram X
        "com.exteragram.messenger",        // Exteragram
        "org.telegram.BifToGram",          // BifToGram
        "nekogram.foss",                   // NekogramX
        "com.nekogram.X",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelegramLaunchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.tg_launch_title)

        setupUI()
        checkAndStart()
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        android.R.id.home -> { onBackPressedDispatcher.onBackPressed(); true }
        else -> super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        searchJob?.cancel()
    }

    // ─── Setup ───────────────────────────────────────────────────────────────

    private fun setupUI() {
        binding.tgBtnRetry.setOnClickListener {
            TelegramStrategyFinder.clearCache(this)
            checkAndStart()
        }

        binding.tgBtnSkip.setOnClickListener {
            openTelegram()
        }

        binding.tgBtnCancel.setOnClickListener {
            searchJob?.cancel()
            showIdle()
        }

        binding.tgBtnOpenDirect.setOnClickListener {
            openTelegram()
        }
    }

    // ─── Main flow ───────────────────────────────────────────────────────────

    private fun checkAndStart() {
        val prefs = getPreferences()

        // 1. Проверяем кэш — если стратегия свежая, сразу применяем
        val cached = TelegramStrategyFinder.getCachedStrategy(this)
        if (cached != null) {
            showCached(cached)
            searchJob = lifecycleScope.launch {
                applyStrategyAndLaunch(cached)
            }
            return
        }

        // 2. Запускаем быстрый поиск
        startSearch()
    }

    private fun startSearch() {
        val prefs = getPreferences()
        val ip = prefs.getStringNotNull("byedpi_proxy_ip", "127.0.0.1")
        val port = prefs.getIntStringNotNull("byedpi_proxy_port", 1080)
        val mode = prefs.mode()

        val strategies = TelegramStrategyFinder.loadStrategies(this)
        if (strategies.isEmpty()) {
            showError(getString(R.string.tg_no_strategies))
            return
        }

        showSearching(strategies.size)

        searchJob = lifecycleScope.launch {
            // Запускаем прокси с первой стратегией для прогрева
            val firstStrategy = strategies.first()
            applyProxyStrategy(firstStrategy, mode)

            // Параллельно ищем лучшую стратегию
            val winner = TelegramStrategyFinder.findFast(
                context = this@TelegramLaunchActivity,
                proxyIp = ip,
                proxyPort = port,
                strategies = strategies,
                onProgress = { idx, total, preview ->
                    withContext(Dispatchers.Main) {
                        binding.tgProgressBar.progress = ((idx + 1) * 100 / total)
                        binding.tgStatusText.text = getString(
                            R.string.tg_testing_strategy, idx + 1, total
                        )
                        binding.tgStrategyPreview.text = preview
                    }
                },
                onFound = { strategy ->
                    withContext(Dispatchers.Main) {
                        showFound(strategy)
                    }
                }
            )

            if (!isActive) return@launch

            if (winner != null) {
                withContext(Dispatchers.Main) { showFound(winner) }
                applyStrategyAndLaunch(winner)
            } else {
                withContext(Dispatchers.Main) {
                    showError(getString(R.string.tg_no_strategy_found))
                }
            }
        }
    }

    // ─── Strategy application ─────────────────────────────────────────────

    private suspend fun applyProxyStrategy(strategy: String, mode: Mode) {
        withContext(Dispatchers.IO) {
            // Проверяем VPN-разрешение — если нет, переключаемся в Proxy
            val effectiveMode = if (mode == Mode.VPN) {
                if (VpnService.prepare(this@TelegramLaunchActivity) == null) Mode.VPN
                else Mode.Proxy  // На EMUI 15 VPN-диалог может не появиться в фоне
            } else mode

            TelegramStrategyFinder.applyAndStart(
                this@TelegramLaunchActivity, strategy, effectiveMode
            )
        }
    }

    private suspend fun applyStrategyAndLaunch(strategy: String) {
        withContext(Dispatchers.Main) {
            binding.tgStatusText.text = getString(R.string.tg_applying_strategy)
        }

        withContext(Dispatchers.IO) {
            val mode = getPreferences().mode()
            applyProxyStrategy(strategy, mode)
            // Ждём старта прокси
            TelegramStrategyFinder.waitForStatus(AppStatus.Running, 5000L)
        }

        // Небольшая пауза для стабилизации — особенно нужна на EMUI 15
        val stabilizeMs = if (HuaweiUtils.isEmui15OrAbove) 800L else 400L
        delay(stabilizeMs)

        withContext(Dispatchers.Main) {
            openTelegram()
        }
    }

    // ─── Telegram launch ──────────────────────────────────────────────────

    private fun openTelegram() {
        val installed = TG_PACKAGES.firstOrNull { pkg ->
            try {
                packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) { false }
        }

        if (installed != null) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(installed)
                    ?.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                if (intent != null) {
                    startActivity(intent)
                    finish()
                    return
                }
            } catch (e: Exception) {
                android.util.Log.e("TgLaunch", "Failed to launch $installed", e)
            }
        }

        // Telegram не установлен — открываем Play Store
        try {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("market://details?id=org.telegram.messenger")))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse(
                    "https://play.google.com/store/apps/details?id=org.telegram.messenger"
                )))
        }

        Toast.makeText(this, R.string.tg_not_installed, Toast.LENGTH_LONG).show()
    }

    // ─── UI states ────────────────────────────────────────────────────────

    private fun showIdle() {
        binding.apply {
            tgSearchCard.visibility = View.GONE
            tgFoundCard.visibility = View.GONE
            tgErrorCard.visibility = View.GONE
            tgIdleCard.visibility = View.VISIBLE
        }
    }

    private fun showSearching(total: Int) {
        binding.apply {
            tgIdleCard.visibility = View.GONE
            tgFoundCard.visibility = View.GONE
            tgErrorCard.visibility = View.GONE
            tgSearchCard.visibility = View.VISIBLE
            tgProgressBar.max = 100
            tgProgressBar.progress = 0
            tgStatusText.text = getString(R.string.tg_searching, total)
            tgStrategyPreview.text = ""
            tgBtnCancel.visibility = View.VISIBLE
            tgBtnSkip.visibility = View.VISIBLE
        }
    }

    private fun showCached(strategy: String) {
        binding.apply {
            tgIdleCard.visibility = View.GONE
            tgErrorCard.visibility = View.GONE
            tgFoundCard.visibility = View.GONE
            tgSearchCard.visibility = View.VISIBLE
            tgStatusText.text = getString(R.string.tg_using_cached)
            tgStrategyPreview.text = strategy.take(60)
            tgProgressBar.progress = 100
            tgBtnCancel.visibility = View.GONE
            tgBtnSkip.visibility = View.VISIBLE
        }
    }

    private fun showFound(strategy: String) {
        binding.apply {
            tgSearchCard.visibility = View.GONE
            tgErrorCard.visibility = View.GONE
            tgIdleCard.visibility = View.GONE
            tgFoundCard.visibility = View.VISIBLE
            tgFoundStrategy.text = strategy.take(80)
            tgFoundStatusText.text = getString(R.string.tg_strategy_found)
        }
    }

    private fun showError(message: String) {
        binding.apply {
            tgSearchCard.visibility = View.GONE
            tgFoundCard.visibility = View.GONE
            tgIdleCard.visibility = View.GONE
            tgErrorCard.visibility = View.VISIBLE
            tgErrorText.text = message
        }
    }
}
