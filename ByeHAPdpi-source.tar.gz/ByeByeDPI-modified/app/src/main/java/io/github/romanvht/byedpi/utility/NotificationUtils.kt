package io.github.romanvht.byedpi.utility

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.activities.MainActivity
import io.github.romanvht.byedpi.data.PAUSE_ACTION
import io.github.romanvht.byedpi.data.RESUME_ACTION
import io.github.romanvht.byedpi.data.STOP_ACTION

fun registerNotificationChannel(context: Context, id: String, @StringRes name: Int) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        // EMUI 15 агрессивно убивает сервисы с LOW-priority уведомлениями.
        // HIGH importance — критично для выживания VPN-сервиса на Huawei Pura 80.
        val importance = if (HuaweiUtils.isHuaweiDevice) {
            NotificationManager.IMPORTANCE_HIGH
        } else {
            NotificationManager.IMPORTANCE_DEFAULT
        }

        val channel = NotificationChannel(id, context.getString(name), importance).apply {
            enableLights(false)
            enableVibration(false)
            setShowBadge(false)
            // На EMUI отключаем звук явно, иначе HIGH вызывает звук
            setSound(null, null)
            // Блокируем появление на экране блокировки EMUI
            lockscreenVisibility = Notification.VISIBILITY_SECRET
        }

        manager.createNotificationChannel(channel)
    }
}

fun createConnectionNotification(
    context: Context,
    channelId: String,
    @StringRes title: Int,
    @StringRes content: Int,
    service: Class<*>,
): Notification {
    val builder = NotificationCompat.Builder(context, channelId)
        .setSmallIcon(R.drawable.ic_notification)
        .setSilent(true)
        .setOngoing(true) // Постоянное уведомление — EMUI не сможет смахнуть
        .setContentTitle(context.getString(title))
        .setContentText(context.getString(content))
        .setPriority(
            // EMUI 15 требует HIGH чтобы не убить сервис
            if (HuaweiUtils.isHuaweiDevice) NotificationCompat.PRIORITY_HIGH
            else NotificationCompat.PRIORITY_DEFAULT
        )
        .addAction(0, context.getString(R.string.service_pause_btn),
            PendingIntent.getService(
                context, 0,
                Intent(context, service).setAction(PAUSE_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .addAction(0, context.getString(R.string.service_stop_btn),
            PendingIntent.getService(
                context, 0,
                Intent(context, service).setAction(STOP_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .setContentIntent(
            PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )

    // Только на EMUI — foregroundServiceBehavior нужен для стабильности
    if (HuaweiUtils.isHuaweiDevice && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        builder.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
    }

    return builder.build()
}

fun createPauseNotification(
    context: Context,
    channelId: String,
    @StringRes title: Int,
    @StringRes content: Int,
    service: Class<*>,
): Notification =
    NotificationCompat.Builder(context, channelId)
        .setSmallIcon(R.drawable.ic_notification)
        .setSilent(true)
        .setContentTitle(context.getString(title))
        .setContentText(context.getString(content))
        .addAction(0, context.getString(R.string.service_start_btn),
            PendingIntent.getService(
                context, 0,
                Intent(context, service).setAction(RESUME_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .setContentIntent(
            PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .build()
