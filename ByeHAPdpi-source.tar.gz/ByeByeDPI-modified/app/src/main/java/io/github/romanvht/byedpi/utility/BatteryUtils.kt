package io.github.romanvht.byedpi.utility

import android.annotation.SuppressLint
import android.provider.Settings
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.net.toUri

object BatteryUtils {
    private const val TAG = "BatteryUtils"

    fun isOptimizationDisabled(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            powerManager.isIgnoringBatteryOptimizations(context.packageName)
        } else {
            true
        }
    }

    @SuppressLint("BatteryLife")
    fun requestBatteryOptimization(context: Context) {
        // На Huawei EMUI нужно открывать нативный экран защищённых приложений
        if (HuaweiUtils.isHuaweiDevice) {
            requestHuaweiBatteryOptimization(context)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = "package:${context.packageName}".toUri()
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to request ignore battery optimizations", e)
                try {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    context.startActivity(intent)
                } catch (e2: Exception) {
                    Log.e(TAG, "Failed to open battery optimization settings", e2)
                }
            }
        }
    }

    /**
     * Для Huawei EMUI 15 нужно:
     * 1. Стандартный запрос IGNORE_BATTERY_OPTIMIZATIONS
     * 2. Открыть экран «Защищённые приложения» EMUI
     */
    @SuppressLint("BatteryLife")
    private fun requestHuaweiBatteryOptimization(context: Context) {
        Log.i(TAG, "Requesting Huawei-specific battery optimization (EMUI ${HuaweiUtils.emuiVersion})")

        // Шаг 1: Стандартный Android запрос
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = "package:${context.packageName}".toUri()
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) { }
        }

        // Шаг 2: Открываем Huawei System Manager — Protected Apps
        val opened = HuaweiUtils.openHuaweiProtectedApps(context)
        if (!opened) {
            // Fallback: общие настройки батареи EMUI
            HuaweiUtils.openHuaweiBatterySettings(context)
        }
    }
}
