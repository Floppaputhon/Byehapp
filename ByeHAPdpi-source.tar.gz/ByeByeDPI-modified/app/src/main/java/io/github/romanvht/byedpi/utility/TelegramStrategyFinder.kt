package io.github.romanvht.byedpi.utility

import android.content.Context
import io.github.romanvht.byedpi.data.AppStatus
import io.github.romanvht.byedpi.data.Mode

object TelegramStrategyFinder {

    const val SERVICE_KEY = "telegram"
    const val ASSET_FILE  = "telegram_strategies.list"

    private val PROBE_URLS = listOf(
        "https://telegram.org",
        "https://t.me",
        "https://web.telegram.org"
    )

    fun loadStrategies(context: Context) =
        QuickStrategyFinder.loadStrategies(context, ASSET_FILE)

    fun getCachedStrategy(context: Context) =
        QuickStrategyFinder.getCachedStrategy(context, SERVICE_KEY)

    fun saveWorkingStrategy(context: Context, strategy: String) =
        QuickStrategyFinder.saveWorkingStrategy(context, SERVICE_KEY, strategy)

    fun clearCache(context: Context) =
        QuickStrategyFinder.clearCache(context, SERVICE_KEY)

    suspend fun findFast(
        context: Context,
        proxyIp: String,
        proxyPort: Int,
        strategies: List<String>,
        onProgress: suspend (Int, Int, String) -> Unit = { _, _, _ -> },
        onFound: suspend (String) -> Unit = {}
    ) = QuickStrategyFinder.findFast(
        context, SERVICE_KEY, proxyIp, proxyPort,
        strategies, PROBE_URLS,
        onProgress = onProgress, onFound = onFound
    )

    suspend fun waitForStatus(target: AppStatus, timeoutMs: Long = 8000L) =
        QuickStrategyFinder.waitForStatus(target, timeoutMs)

    suspend fun applyAndStart(context: Context, strategy: String, mode: Mode) =
        QuickStrategyFinder.applyAndStart(context, strategy, mode)
}
