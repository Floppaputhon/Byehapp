package io.github.romanvht.byedpi.activities

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.data.AppStatus
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.databinding.ActivityYoutubeLaunchBinding
import io.github.romanvht.byedpi.services.ServiceManager
import io.github.romanvht.byedpi.services.appStatus
import io.github.romanvht.byedpi.utility.*
import kotlinx.coroutines.*

class YoutubeLaunchActivity : BaseActivity() {

    private lateinit var binding: ActivityYoutubeLaunchBinding
    private var searchJob: Job? = null

    // YouTube app package names
    private val YT_PACKAGES = listOf(
        "com.google.android.youtube",        // Official YouTube
        "com.vanced.android.youtube",        // Vanced (legacy)
        "app.revanced.android.youtube",      // ReVanced
        "com.github.libretube",              // LibreTube
        "io.freetubeapp.freetube",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityYoutubeLaunchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.yt_launch_title)
        setupUI()
        checkAndStart()
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        android.R.id.home -> { onBackPressedDispatcher.onBackPressed(); true }
        else -> super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        searchJob?.cancel()
    }

    private fun setupUI() {
        binding.ytBtnRetry.setOnClickListener {
            YoutubeStrategyFinder.clearCache(this)
            checkAndStart()
        }
        binding.ytBtnSkip.setOnClickListener { openYoutube() }
        binding.ytBtnCancel.setOnClickListener {
            searchJob?.cancel()
            showIdle()
        }
        binding.ytBtnOpenDirect.setOnClickListener { openYoutube() }
        binding.ytBtnOpenBrowser.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
        }
    }

    // ─── Main flow ───────────────────────────────────────────────────────────

    private fun checkAndStart() {
        val cached = YoutubeStrategyFinder.getCachedStrategy(this)
        if (cached != null) {
            showCached(cached)
            searchJob = lifecycleScope.launch { applyAndLaunch(cached) }
            return
        }
        startSearch()
    }

    private fun startSearch() {
        val prefs = getPreferences()
        val ip = prefs.getStringNotNull("byedpi_proxy_ip", "127.0.0.1")
        val port = prefs.getIntStringNotNull("byedpi_proxy_port", 1080)
        val mode = prefs.mode()
        val strategies = YoutubeStrategyFinder.loadStrategies(this)

        if (strategies.isEmpty()) {
            showError(getString(R.string.yt_no_strategies))
            return
        }

        showSearching(strategies.size)

        searchJob = lifecycleScope.launch {
            // Стартуем прокси с первой стратегией пока идёт поиск
            withContext(Dispatchers.IO) {
                applyProxy(strategies.first(), mode)
            }

            val winner = YoutubeStrategyFinder.findFast(
                context = this@YoutubeLaunchActivity,
                proxyIp = ip,
                proxyPort = port,
                strategies = strategies,
                onProgress = { idx, total, preview ->
                    withContext(Dispatchers.Main) {
                        binding.ytProgressBar.progress = ((idx + 1) * 100 / total)
                        binding.ytStatusText.text =
                            getString(R.string.yt_testing_strategy, idx + 1, total)
                        binding.ytStrategyPreview.text = preview
                    }
                },
                onFound = { strategy ->
                    withContext(Dispatchers.Main) { showFound(strategy) }
                }
            )

            if (!isActive) return@launch

            if (winner != null) {
                withContext(Dispatchers.Main) { showFound(winner) }
                applyAndLaunch(winner)
            } else {
                withContext(Dispatchers.Main) {
                    showError(getString(R.string.yt_no_strategy_found))
                }
            }
        }
    }

    private suspend fun applyProxy(strategy: String, mode: Mode) {
        val effectiveMode = if (mode == Mode.VPN &&
            VpnService.prepare(this) == null) Mode.VPN else Mode.Proxy
        YoutubeStrategyFinder.applyAndStart(this, strategy, effectiveMode)
    }

    private suspend fun applyAndLaunch(strategy: String) {
        withContext(Dispatchers.Main) {
            binding.ytStatusText.text = getString(R.string.yt_applying_strategy)
        }
        withContext(Dispatchers.IO) {
            val mode = getPreferences().mode()
            applyProxy(strategy, mode)
            YoutubeStrategyFinder.waitForStatus(AppStatus.Running, 5000L)
        }
        delay(QuickStrategyFinder.STABILIZE_MS)
        withContext(Dispatchers.Main) { openYoutube() }
    }

    // ─── Open YouTube ────────────────────────────────────────────────────────

    private fun openYoutube() {
        // Пробуем нативное приложение
        val installed = YT_PACKAGES.firstOrNull { pkg ->
            try { packageManager.getPackageInfo(pkg, 0); true }
            catch (_: Exception) { false }
        }

        if (installed != null) {
            packageManager.getLaunchIntentForPackage(installed)
                ?.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                ?.let { startActivity(it); finish(); return }
        }

        // Fallback: открываем в браузере
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.yt_not_installed, Toast.LENGTH_LONG).show()
        }
    }

    // ─── UI states ───────────────────────────────────────────────────────────

    private fun showIdle() = with(binding) {
        ytSearchCard.visibility = View.GONE
        ytFoundCard.visibility = View.GONE
        ytErrorCard.visibility = View.GONE
        ytIdleCard.visibility = View.VISIBLE
    }

    private fun showSearching(total: Int) = with(binding) {
        ytIdleCard.visibility = View.GONE
        ytFoundCard.visibility = View.GONE
        ytErrorCard.visibility = View.GONE
        ytSearchCard.visibility = View.VISIBLE
        ytProgressBar.max = 100
        ytProgressBar.progress = 0
        ytStatusText.text = getString(R.string.yt_searching, total)
        ytStrategyPreview.text = ""
        ytBtnCancel.visibility = View.VISIBLE
        ytBtnSkip.visibility = View.VISIBLE
    }

    private fun showCached(strategy: String) = with(binding) {
        ytIdleCard.visibility = View.GONE
        ytErrorCard.visibility = View.GONE
        ytFoundCard.visibility = View.GONE
        ytSearchCard.visibility = View.VISIBLE
        ytStatusText.text = getString(R.string.yt_using_cached)
        ytStrategyPreview.text = strategy.take(60)
        ytProgressBar.progress = 100
        ytBtnCancel.visibility = View.GONE
        ytBtnSkip.visibility = View.VISIBLE
    }

    private fun showFound(strategy: String) = with(binding) {
        ytSearchCard.visibility = View.GONE
        ytErrorCard.visibility = View.GONE
        ytIdleCard.visibility = View.GONE
        ytFoundCard.visibility = View.VISIBLE
        ytFoundStrategy.text = strategy.take(80)
        ytFoundStatusText.text = getString(R.string.yt_strategy_found)
    }

    private fun showError(message: String) = with(binding) {
        ytSearchCard.visibility = View.GONE
        ytFoundCard.visibility = View.GONE
        ytIdleCard.visibility = View.GONE
        ytErrorCard.visibility = View.VISIBLE
        ytErrorText.text = message
    }
}
