package io.github.romanvht.byedpi.activities

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.adapters.VlessAdapter
import io.github.romanvht.byedpi.databinding.ActivityVlessBinding
import io.github.romanvht.byedpi.utility.ClipboardUtils
import io.github.romanvht.byedpi.utility.VlessUtils

class VlessActivity : BaseActivity() {

    private lateinit var binding: ActivityVlessBinding
    private lateinit var adapter: VlessAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVlessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.vless_title)

        setupRecyclerView()
        setupButtons()
        loadConfigs()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        adapter = VlessAdapter(
            configs = mutableListOf(),
            onSelect = { config ->
                VlessUtils.setActive(this, config.id)
                loadConfigs()
                Toast.makeText(this, getString(R.string.vless_key_activated, config.remark), Toast.LENGTH_SHORT).show()
            },
            onDelete = { config ->
                VlessUtils.deleteConfig(this, config.id)
                loadConfigs()
                Toast.makeText(this, R.string.vless_key_deleted, Toast.LENGTH_SHORT).show()
            },
            onCopy = { config ->
                ClipboardUtils.copy(this, config.rawUri, showToast = false)
                Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show()
            }
        )

        binding.vlessRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.vlessRecyclerView.adapter = adapter
    }

    private fun setupButtons() {
        binding.vlessPasteBtn.setOnClickListener {
            val text = ClipboardUtils.paste(this)?.trim() ?: ""
            if (text.isNotBlank()) {
                binding.vlessInputEdit.setText(text)
            } else {
                Toast.makeText(this, R.string.vless_clipboard_empty, Toast.LENGTH_SHORT).show()
            }
        }

        binding.vlessClearBtn.setOnClickListener {
            binding.vlessInputEdit.setText("")
        }

        binding.vlessAddBtn.setOnClickListener {
            val input = binding.vlessInputEdit.text.toString().trim()
            if (input.isBlank()) {
                Toast.makeText(this, R.string.vless_input_empty, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Handle multiple keys (one per line or separated by newlines)
            val lines = input.lines().map { it.trim() }.filter { it.isNotBlank() }
            var added = 0
            var failed = 0

            for (line in lines) {
                val config = VlessUtils.addConfig(this, line)
                if (config != null) added++ else failed++
            }

            when {
                added > 0 && failed == 0 -> {
                    Toast.makeText(this, getString(R.string.vless_added_count, added), Toast.LENGTH_SHORT).show()
                    binding.vlessInputEdit.setText("")
                }
                added > 0 -> {
                    Toast.makeText(this, getString(R.string.vless_added_partial, added, failed), Toast.LENGTH_SHORT).show()
                    binding.vlessInputEdit.setText("")
                }
                else -> {
                    Toast.makeText(this, R.string.vless_invalid_key, Toast.LENGTH_SHORT).show()
                }
            }

            loadConfigs()
        }

        binding.vlessDeactivateBtn.setOnClickListener {
            VlessUtils.clearActive(this)
            loadConfigs()
            Toast.makeText(this, R.string.vless_deactivated, Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadConfigs() {
        val configs = VlessUtils.getConfigs(this)
        adapter.updateData(configs)

        val hasActive = configs.any { it.isActive }
        binding.vlessDeactivateBtn.visibility = if (hasActive) View.VISIBLE else View.GONE
        binding.vlessEmptyText.visibility = if (configs.isEmpty()) View.VISIBLE else View.GONE
        binding.vlessRecyclerView.visibility = if (configs.isEmpty()) View.GONE else View.VISIBLE

        // Show active key info in header
        val active = configs.firstOrNull { it.isActive }
        if (active != null) {
            binding.vlessActiveCard.visibility = View.VISIBLE
            binding.vlessActiveRemark.text = active.remark
            binding.vlessActiveAddress.text = "${active.address}:${active.port}"
            binding.vlessActiveSecurity.text = VlessUtils.getSecurityLabel(active)
        } else {
            binding.vlessActiveCard.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        loadConfigs()
    }
}
