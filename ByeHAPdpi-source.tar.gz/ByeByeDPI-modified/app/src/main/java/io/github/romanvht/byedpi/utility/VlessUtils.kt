package io.github.romanvht.byedpi.utility

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.github.romanvht.byedpi.data.VlessConfig
import java.io.File
import java.util.UUID

object VlessUtils {

    private const val VLESS_FILE = "vless_configs.json"
    private val gson = Gson()

    fun parseVlessUri(uri: String): VlessConfig? {
        return try {
            val trimmed = uri.trim()
            if (!trimmed.startsWith("vless://")) return null

            val parsed = Uri.parse(trimmed)
            val uuid = parsed.userInfo ?: return null
            val address = parsed.host ?: return null
            val port = parsed.port.takeIf { it > 0 } ?: 443
            val remark = Uri.decode(parsed.fragment ?: "")

            val security = parsed.getQueryParameter("security") ?: ""
            val sni = parsed.getQueryParameter("sni") ?: ""
            val fingerprint = parsed.getQueryParameter("fp") ?: ""
            val flow = parsed.getQueryParameter("flow") ?: ""
            val pbk = parsed.getQueryParameter("pbk") ?: ""
            val sid = parsed.getQueryParameter("sid") ?: ""
            val type = parsed.getQueryParameter("type") ?: "tcp"

            VlessConfig(
                id = UUID.randomUUID().toString(),
                uuid = uuid,
                address = address,
                port = port,
                remark = remark.ifBlank { "$address:$port" },
                security = security,
                sni = sni,
                fingerprint = fingerprint,
                flow = flow,
                pbk = pbk,
                sid = sid,
                type = type,
                rawUri = trimmed
            )
        } catch (e: Exception) {
            null
        }
    }

    fun saveConfigs(context: Context, configs: List<VlessConfig>) {
        val file = File(context.filesDir, VLESS_FILE)
        file.writeText(gson.toJson(configs))
    }

    fun getConfigs(context: Context): List<VlessConfig> {
        val file = File(context.filesDir, VLESS_FILE)
        if (!file.exists()) return emptyList()
        return try {
            val type = object : TypeToken<List<VlessConfig>>() {}.type
            gson.fromJson(file.readText(), type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addConfig(context: Context, uri: String): VlessConfig? {
        val config = parseVlessUri(uri) ?: return null
        val configs = getConfigs(context).toMutableList()
        configs.add(config)
        saveConfigs(context, configs)
        return config
    }

    fun deleteConfig(context: Context, id: String) {
        val configs = getConfigs(context).toMutableList()
        configs.removeAll { it.id == id }
        saveConfigs(context, configs)
    }

    fun setActive(context: Context, id: String) {
        val configs = getConfigs(context).map { config ->
            config.copy(isActive = config.id == id)
        }
        saveConfigs(context, configs)
    }

    fun getActiveConfig(context: Context): VlessConfig? {
        return getConfigs(context).firstOrNull { it.isActive }
    }

    fun clearActive(context: Context) {
        val configs = getConfigs(context).map { it.copy(isActive = false) }
        saveConfigs(context, configs)
    }

    fun getSecurityLabel(config: VlessConfig): String {
        return when (config.security) {
            "reality" -> "Reality"
            "tls" -> "TLS"
            "xtls" -> "XTLS"
            else -> config.security.ifBlank { "None" }
        }
    }

    fun getTypeLabel(config: VlessConfig): String {
        return when (config.type) {
            "tcp" -> "TCP"
            "ws" -> "WebSocket"
            "grpc" -> "gRPC"
            "http" -> "HTTP"
            "h2" -> "HTTP/2"
            else -> config.type.uppercase()
        }
    }
}
