package io.github.romanvht.byedpi.utility

import android.content.Context
import android.os.PowerManager
import android.util.Log

/**
 * Менеджер WakeLock для Huawei EMUI 15.
 *
 * EMUI агрессивно убивает фоновые процессы. WakeLock PARTIAL_WAKE_LOCK
 * предотвращает засыпание CPU во время работы VPN/Proxy.
 *
 * Используется только на Huawei-устройствах — на обычных Android это не нужно.
 */
object HuaweiWakeLockManager {

    private const val TAG = "HuaweiWakeLock"
    private const val WAKE_LOCK_TAG = "ByeHAPdpi:VpnKeepAlive"

    // Таймаут 6 часов — EMUI 15 требует явного таймаута
    private const val WAKE_LOCK_TIMEOUT_MS = 6 * 60 * 60 * 1000L

    private var wakeLock: PowerManager.WakeLock? = null

    fun acquire(context: Context) {
        if (!HuaweiUtils.isHuaweiDevice) return
        if (wakeLock?.isHeld == true) {
            Log.d(TAG, "WakeLock already held")
            return
        }
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                WAKE_LOCK_TAG
            ).apply {
                setReferenceCounted(false)
                acquire(WAKE_LOCK_TIMEOUT_MS)
            }
            Log.i(TAG, "WakeLock acquired (EMUI ${HuaweiUtils.emuiVersion})")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to acquire WakeLock", e)
        }
    }

    fun release() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                Log.i(TAG, "WakeLock released")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to release WakeLock", e)
        } finally {
            wakeLock = null
        }
    }

    val isHeld: Boolean get() = wakeLock?.isHeld == true
}
