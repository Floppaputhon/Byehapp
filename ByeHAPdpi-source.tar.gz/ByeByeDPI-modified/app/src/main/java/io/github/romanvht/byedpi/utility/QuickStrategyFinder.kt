package io.github.romanvht.byedpi.utility

import android.content.Context
import android.util.Log
import io.github.romanvht.byedpi.data.AppStatus
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.services.ServiceManager
import io.github.romanvht.byedpi.services.appStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL

/**
 * Универсальный быстрый подбор стратегии для любого сервиса.
 *
 * Оптимизации под Huawei Pura 80 / EMUI 15:
 * — Параллельность 4 (оптимум для Kirin 9020 без перегрева)
 * — Таймаут 2.5с (только HEAD-запросы)
 * — Ранний выход при первой рабочей стратегии
 * — Кэш 30 мин с ключом per-сервис
 */
object QuickStrategyFinder {

    private const val TAG = "QuickStrategyFinder"
    private const val CACHE_TTL_MS = 30 * 60 * 1000L

    private val PARALLEL_SLOTS get() = if (HuaweiUtils.isEmui15OrAbove) 4 else 6
    private val PROBE_TIMEOUT_MS get() = if (HuaweiUtils.isHuaweiDevice) 2500L else 3500L
    val STABILIZE_MS get() = if (HuaweiUtils.isEmui15OrAbove) 800L else 400L

    // ─── Cache ───────────────────────────────────────────────────────────────

    fun getCachedStrategy(context: Context, serviceKey: String): String? {
        val prefs = context.getPreferences()
        val ts = prefs.getLong("qs_ts_$serviceKey", 0L)
        if (System.currentTimeMillis() - ts > CACHE_TTL_MS) return null
        return prefs.getString("qs_strategy_$serviceKey", null)
            .also { if (it != null) Log.i(TAG, "[$serviceKey] Cache hit: ${it.take(40)}") }
    }

    fun saveWorkingStrategy(context: Context, serviceKey: String, strategy: String) {
        context.getPreferences().edit()
            .putString("qs_strategy_$serviceKey", strategy)
            .putLong("qs_ts_$serviceKey", System.currentTimeMillis())
            .apply()
        Log.i(TAG, "[$serviceKey] Saved: ${strategy.take(40)}")
    }

    fun clearCache(context: Context, serviceKey: String) {
        context.getPreferences().edit()
            .remove("qs_strategy_$serviceKey")
            .remove("qs_ts_$serviceKey")
            .apply()
    }

    // ─── Strategy loading ─────────────────────────────────────────────────

    fun loadStrategies(context: Context, assetFile: String): List<String> {
        return try {
            context.assets.open(assetFile)
                .bufferedReader()
                .readLines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load $assetFile", e)
            emptyList()
        }
    }

    // ─── Core finder ─────────────────────────────────────────────────────

    /**
     * Параллельный поиск первой рабочей стратегии.
     *
     * @param probeUrls   список URL для проверки (HEAD-запросы)
     * @param minScore    минимум успешных ответов для победы (обычно = probeUrls.size)
     * @param onProgress  (index, total, strategyPreview)
     * @param onFound     вызывается немедленно при нахождении
     * @return рабочая стратегия или null
     */
    suspend fun findFast(
        context: Context,
        serviceKey: String,
        proxyIp: String,
        proxyPort: Int,
        strategies: List<String>,
        probeUrls: List<String>,
        minScore: Int = probeUrls.size,
        onProgress: suspend (Int, Int, String) -> Unit = { _, _, _ -> },
        onFound: suspend (String) -> Unit = {}
    ): String? = withContext(Dispatchers.IO) {

        Log.i(TAG, "[$serviceKey] start: ${strategies.size} strategies, " +
            "parallel=$PARALLEL_SLOTS, timeout=${PROBE_TIMEOUT_MS}ms, " +
            "Huawei=${HuaweiUtils.isHuaweiDevice}, EMUI15=${HuaweiUtils.isEmui15OrAbove}")

        val semaphore = Semaphore(PARALLEL_SLOTS)
        val found = CompletableDeferred<String?>()

        val jobs = strategies.mapIndexed { index, strategy ->
            async {
                if (found.isCompleted) return@async
                semaphore.withPermit {
                    if (found.isCompleted) return@withPermit
                    onProgress(index, strategies.size, strategy.take(60))
                    try {
                        val score = probe(proxyIp, proxyPort, probeUrls)
                        Log.d(TAG, "[$serviceKey] #$index score=$score/${probeUrls.size}")
                        if (score >= minScore && !found.isCompleted) {
                            found.complete(strategy)
                            onFound(strategy)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.w(TAG, "[$serviceKey] probe error #$index: ${e.message}")
                    }
                }
            }
        }

        val timeout = (strategies.size * PROBE_TIMEOUT_MS * 2).coerceAtMost(90_000L)
        val winner = withTimeoutOrNull(timeout) {
            val watcher = launch {
                found.await()
                jobs.forEach { it.cancel() }
            }
            jobs.awaitAll()
            watcher.cancel()
            if (found.isCompleted) found.getCompleted() else null
        }

        if (winner != null) saveWorkingStrategy(context, serviceKey, winner)
        Log.i(TAG, "[$serviceKey] done. winner=${winner?.take(40)}")
        winner
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private suspend fun probe(
        proxyIp: String,
        proxyPort: Int,
        urls: List<String>
    ): Int = withContext(Dispatchers.IO) {
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress(proxyIp, proxyPort))
        var ok = 0
        for (url in urls) {
            try {
                val conn = URL(url).openConnection(proxy) as HttpURLConnection
                conn.connectTimeout = PROBE_TIMEOUT_MS.toInt()
                conn.readTimeout = PROBE_TIMEOUT_MS.toInt()
                conn.requestMethod = "HEAD"
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("Connection", "close")
                val code = conn.responseCode
                conn.disconnect()
                if (code in 200..399) ok++
            } catch (_: IOException) { }
        }
        ok
    }

    suspend fun waitForStatus(target: AppStatus, timeoutMs: Long = 8000L): Boolean {
        val poll = if (HuaweiUtils.isHuaweiDevice) 80L else 150L
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (appStatus.first == target) return true
            delay(poll)
        }
        return appStatus.first == target
    }

    suspend fun applyAndStart(context: Context, strategy: String, mode: Mode) {
        context.getPreferences().edit()
            .putString("byedpi_cmd_args", strategy)
            .putBoolean("byedpi_enable_cmd_settings", true)
            .apply()
        if (appStatus.first == AppStatus.Running) {
            ServiceManager.stop(context)
            waitForStatus(AppStatus.Halted)
        }
        ServiceManager.start(context, mode)
    }
}
