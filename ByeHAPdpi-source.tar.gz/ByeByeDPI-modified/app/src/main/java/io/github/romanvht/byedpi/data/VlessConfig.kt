package io.github.romanvht.byedpi.data

data class VlessConfig(
    val id: String,
    val uuid: String,
    val address: String,
    val port: Int,
    val remark: String,
    val security: String,
    val sni: String,
    val fingerprint: String,
    val flow: String,
    val pbk: String,
    val sid: String,
    val type: String,
    val rawUri: String,
    val isActive: Boolean = false
)
