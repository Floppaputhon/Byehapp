package io.github.romanvht.byedpi.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.data.VlessConfig
import io.github.romanvht.byedpi.utility.VlessUtils

class VlessAdapter(
    private var configs: MutableList<VlessConfig>,
    private val onSelect: (VlessConfig) -> Unit,
    private val onDelete: (VlessConfig) -> Unit,
    private val onCopy: (VlessConfig) -> Unit
) : RecyclerView.Adapter<VlessAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val remarkText: TextView = view.findViewById(R.id.vless_remark)
        val addressText: TextView = view.findViewById(R.id.vless_address)
        val securityBadge: TextView = view.findViewById(R.id.vless_security_badge)
        val typeBadge: TextView = view.findViewById(R.id.vless_type_badge)
        val activeIcon: ImageView = view.findViewById(R.id.vless_active_icon)
        val deleteBtn: ImageButton = view.findViewById(R.id.vless_delete_btn)
        val copyBtn: ImageButton = view.findViewById(R.id.vless_copy_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_vless_key, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val config = configs[position]
        val ctx = holder.itemView.context

        holder.remarkText.text = config.remark
        holder.addressText.text = "${config.address}:${config.port}"
        holder.securityBadge.text = VlessUtils.getSecurityLabel(config)
        holder.typeBadge.text = VlessUtils.getTypeLabel(config)

        if (config.isActive) {
            holder.activeIcon.visibility = View.VISIBLE
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(ctx, R.color.vless_active_bg)
            )
        } else {
            holder.activeIcon.visibility = View.GONE
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(ctx, android.R.color.transparent)
            )
        }

        holder.itemView.setOnClickListener { onSelect(config) }
        holder.deleteBtn.setOnClickListener { onDelete(config) }
        holder.copyBtn.setOnClickListener { onCopy(config) }
    }

    override fun getItemCount() = configs.size

    fun updateData(newConfigs: List<VlessConfig>) {
        configs.clear()
        configs.addAll(newConfigs)
        notifyDataSetChanged()
    }
}
