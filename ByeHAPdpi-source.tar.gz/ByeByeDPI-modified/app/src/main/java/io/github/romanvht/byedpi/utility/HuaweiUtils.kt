package io.github.romanvht.byedpi.utility

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * Утилиты для оптимизации под Huawei EMUI / HarmonyOS
 * Оптимизировано для Huawei Pura 80 (EMUI 15 / HarmonyOS NEXT)
 */
object HuaweiUtils {

    private const val TAG = "HuaweiUtils"

    // Признаки Huawei / HarmonyOS устройства
    val isHuaweiDevice: Boolean by lazy {
        Build.MANUFACTURER.equals("HUAWEI", ignoreCase = true) ||
        Build.BRAND.equals("HUAWEI", ignoreCase = true) ||
        Build.BRAND.equals("HONOR", ignoreCase = true)
    }

    val isHarmonyOS: Boolean by lazy {
        try {
            Class.forName("com.huawei.system.BuildEx") != null
        } catch (_: ClassNotFoundException) { false }
    }

    val emuiVersion: String by lazy {
        getSystemProperty("ro.build.version.emui") ?: "unknown"
    }

    val harmonyVersion: String by lazy {
        getSystemProperty("hw_sc.build.platform.version") ?:
        getSystemProperty("ro.build.version.harmony") ?: "unknown"
    }

    /** EMUI 15 = HarmonyOS NEXT поколение (Pura 80) */
    val isEmui15OrAbove: Boolean by lazy {
        if (!isHuaweiDevice) return@lazy false
        val v = emuiVersion.removePrefix("EmotionUI_").split(".").firstOrNull()?.toIntOrNull() ?: 0
        v >= 15 || harmonyVersion.split(".").firstOrNull()?.toIntOrNull() ?: 0 >= 5
    }

    // ─── Battery / Protected Apps ────────────────────────────────────────────

    /**
     * Открывает экран «Защищённые приложения» в системном менеджере Huawei.
     * Это критично для EMUI 15 — без этого сервис убивается в фоне.
     */
    fun openHuaweiProtectedApps(context: Context): Boolean {
        if (!isHuaweiDevice) return false
        val intents = listOf(
            // EMUI 15 / HarmonyOS NEXT
            Intent().apply {
                setClassName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            // EMUI 12–14
            Intent().apply {
                setClassName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.optimize.process.ProtectActivity"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            // Honor / lite EMUI
            Intent().apply {
                setClassName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
        for (intent in intents) {
            try {
                context.startActivity(intent)
                Log.i(TAG, "Opened protected apps: ${intent.component?.className}")
                return true
            } catch (_: Exception) { }
        }
        Log.w(TAG, "Could not open Huawei protected apps screen")
        return false
    }

    /**
     * Открывает настройки батареи для приложения в EMUI.
     */
    fun openHuaweiBatterySettings(context: Context): Boolean {
        if (!isHuaweiDevice) return false
        val intents = listOf(
            Intent().apply {
                setClassName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            Intent().apply {
                setClassName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.optimize.bootstart.BootStartActivity"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
        for (intent in intents) {
            try {
                context.startActivity(intent)
                return true
            } catch (_: Exception) { }
        }
        return false
    }

    // ─── Display / UI ─────────────────────────────────────────────────────────

    /**
     * Huawei Pura 80 имеет изогнутый экран 6.8" с частотой 120 Гц.
     * DynamicColors (Material You) НЕ поддерживается на EMUI без HMS — нужна защита.
     */
    val supportsDynamicColors: Boolean by lazy {
        !isHuaweiDevice || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && hasHmsInstalled()
    }

    private fun hasHmsInstalled(): Boolean {
        return try {
            Class.forName("com.huawei.hms.api.HuaweiApiClient") != null
        } catch (_: ClassNotFoundException) { false }
    }

    // ─── Network ──────────────────────────────────────────────────────────────

    /**
     * Оптимальный MTU для Huawei Pura 80.
     * EMUI 15 использует улучшенный сетевой стек — снижаем MTU для стабильности VPN.
     */
    val optimalMtu: Int get() = if (isEmui15OrAbove) 1380 else if (isHuaweiDevice) 1400 else 8500

    /**
     * Оптимальный DNS для Huawei — 180.76.76.76 (Baidu) может быть заблокирован.
     * Используем Cloudflare как первичный, Google как резервный.
     */
    val recommendedDns: String get() = if (isHuaweiDevice) "1.1.1.1" else "8.8.8.8"

    // ─── Helpers ──────────────────────────────────────────────────────────────

    @SuppressLint("PrivateApi")
    private fun getSystemProperty(key: String): String? {
        return try {
            val clazz = Class.forName("android.os.SystemProperties")
            val method = clazz.getMethod("get", String::class.java, String::class.java)
            val result = method.invoke(null, key, "") as? String
            result?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }

    fun logDeviceInfo() {
        Log.i(TAG, "=== Huawei Device Info ===")
        Log.i(TAG, "isHuawei: $isHuaweiDevice | isHarmony: $isHarmonyOS")
        Log.i(TAG, "EMUI: $emuiVersion | Harmony: $harmonyVersion")
        Log.i(TAG, "EMUI15+: $isEmui15OrAbove | MTU: $optimalMtu")
        Log.i(TAG, "DynamicColors: $supportsDynamicColors")
    }
}
